# -*- coding: utf-8 -*-
import sys, re, hashlib, json, ssl, urllib.request, urllib.error, os, xml.etree.ElementTree as ET, datetime, unicodedata, xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
from urllib.parse import urlparse, parse_qsl, urlencode, unquote, quote

# Inicializace
_addon = xbmcaddon.Addon()
_url = sys.argv[0]
_handle = int(sys.argv[1])
_profile_path = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
if not xbmcvfs.exists(_profile_path): xbmcvfs.mkdir(_profile_path)
HISTORY_FILE = os.path.join(_profile_path, 'history.txt')

# Konfigurace
TREZOR_WEB_URL = "http://trezormovies.wz.cz/trezor/api.php"
TMDB_KEY = '16cb6df244a5695120296c6864a11686'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/120.0.0.0'
ctx_unverified = ssl._create_unverified_context()
NAS_BASE_PATH = "smb://192.168.0.109/video/"

# --- POMOCNÉ FUNKCE ---
def get_user_query():
    keyboard = xbmc.Keyboard('', 'Zadejte hledaný výraz')
    keyboard.doModal()
    if keyboard.isConfirmed(): return keyboard.getText()
    return None

def save_to_history(query):
    history = []
    if xbmcvfs.exists(HISTORY_FILE):
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f: history = f.read().splitlines()
    if query and query not in history:
        history.insert(0, query)
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f: f.write('\n'.join(history[:20]))

def get_hellshare_stream(vid_url_part):
    try:
        parts = vid_url_part.split('/')
        if len(parts) < 2: return None
        video_hash, video_id = parts[0], parts[1]
        dl_url = f"https://api.hellspy.to/gw/video/{video_id}/{video_hash}"
        req = urllib.request.Request(dl_url, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=10) as res:
            d = json.loads(res.read().decode('utf-8'))
            return d.get('download') or list(d.get('conversions', {}).values())[0]
    except Exception as e:
        xbmc.log(f"HELLSPY CHYBA: {str(e)}", level=xbmc.LOGERROR)
        return None

def get_tmdb_info(title, is_series=False):
    if not title: return None
    search_type = "tv" if is_series else "multi"
    url = f"https://api.themoviedb.org/3/search/{search_type}?api_key={TMDB_KEY}&query={quote(title)}&language=cs-CZ"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=5, context=ctx_unverified) as res:
            data = json.loads(res.read().decode('utf-8'))
            if data.get('results'):
                item = data['results'][0]
                return {'title': item.get('title') or item.get('name'), 'plot': item.get('overview', ''), 'poster': f"https://image.tmdb.org/t/p/w500{item.get('poster_path')}" if item.get('poster_path') else None}
    except: pass
    return None

def python_md5crypt(password, salt):
    if salt.startswith('$1$'): salt = salt.split('$')[2]
    elif '$' in salt: salt = salt.split('$')[0]
    salt = salt[:8]
    p, s = password.encode('utf-8'), salt.encode('utf-8')
    ctx = hashlib.md5(p + b"$1$" + s)
    ctx1 = hashlib.md5(p + s + p).digest()
    plen = len(p)
    for i in range(plen, 0, -16): ctx.update(ctx1[:16] if i > 16 else ctx1[:i])
    i = plen
    while i > 0:
        ctx.update(b"\x00" if i & 1 else p[:1])
        i >>= 1
    final = ctx.digest()
    for i in range(1000):
        ctx1 = hashlib.md5()
        ctx1.update(p if i & 1 else final[:16])
        if i % 3: ctx1.update(s)
        if i % 7: ctx1.update(p)
        ctx1.update(final[:16] if i & 1 else p)
        final = ctx1.digest()
    itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    res = b"$1$" + s + b"$"
    def l64(v, n):
        r = b""
        while n > 0:
            r += itoa64[v & 0x3f].encode('ascii')
            v >>= 6; n -= 1
        return r
    final = list(final)
    res += l64((final[0]<<16)|(final[6]<<8)|final[12], 4)
    res += l64((final[1]<<16)|(final[7]<<8)|final[13], 4)
    res += l64((final[2]<<16)|(final[8]<<8)|final[14], 4)
    res += l64((final[3]<<16)|(final[9]<<8)|final[15], 4)
    res += l64((final[4]<<16)|(final[10]<<8)|final[5], 4)
    res += l64(final[11], 2)
    return res.decode('ascii')

def revalidate():
    username, password = str(_addon.getSetting('wsuser')).strip(), str(_addon.getSetting('wspass')).strip()
    if not username or not password: return None
    try:
        url_salt = "https://webshare.cz/api/salt/"
        with urllib.request.urlopen(urllib.request.Request(url_salt, data=urlencode({'username_or_email': username}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as response:
            salt = re.search(r'<salt>([^<]+)</salt>', response.read().decode()).group(1)
        crypt_str = python_md5crypt(password, salt)
        final_password_hash = hashlib.sha1(crypt_str.encode()).hexdigest().lower()
        final_digest = hashlib.md5(f"{username}:Webshare:{password}".encode()).hexdigest().upper()
        url_login = "https://webshare.cz/api/login/"
        with urllib.request.urlopen(urllib.request.Request(url_login, data=urlencode({'username_or_email': username, 'password': final_password_hash, 'digest': final_digest}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as response:
            res = response.read().decode()
            if 'OK' in res: return re.search(r'<token>([^<]+)</token>', res).group(1)
    except: pass
    return None

def getlink(ident, token):
    try:
        with urllib.request.urlopen(urllib.request.Request("https://webshare.cz/api/file_link/", data=urlencode({'ident': ident, 'wst': token}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as res:
            return re.search(r'<link>([^<]+)</link>', res.read().decode()).group(1)
    except: return None

def get_webshare_vip_info(token):
    if not token: return "Webshare: Nepřihlášen"
    try:
        url = "https://webshare.cz/api/user_data/"
        req = urllib.request.Request(url, data=urlencode({'wst': token}).encode(), headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=8, context=ctx_unverified) as response:
            res_data = response.read().decode('utf-8')
            username = re.search(r'<username>([^<]+)</username>', res_data).group(1)
            vip_days_match = re.search(r'<vip_days>([^<]+)</vip_days>', res_data)
            dny = int(vip_days_match.group(1)) if vip_days_match else 0
            return f"Uživatel: {username} | VIP: {dny} dní"
    except: return "Webshare status: Nedostupný"

def get_url(**kwargs): return f"{_url}?{urlencode(kwargs)}"

def search_hellspy(query):
    url = f"https://api.hellspy.to/gw/search?query={quote(query)}&limit=20"
    try:
        req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/json', 'Referer': 'https://www.hellspy.to/'})
        with urllib.request.urlopen(req, timeout=10) as res:
            data = json.loads(res.read().decode('utf-8'))
            return [{'label': f"[Hellspy] {item.get('title')}", 'id': item.get('id'), 'hash': item.get('fileHash')} for item in data.get('items', []) if item.get('objectType') == 'GWSearchVideo']
    except: return []

# --- HLEDÁNÍ ---
def search_both(params):
    query = params.get('query', '')
    if not query: return
    xbmcplugin.setContent(_handle, 'movies')
    tmdb = get_tmdb_info(query)
    
    for r in search_hellspy(query):
        clean_label = r['label'].replace('[Hellspy] ', '')
        li = xbmcgui.ListItem(label=f"[COLOR blue][HS][/COLOR] {clean_label}")
        if tmdb:
            if tmdb.get('poster'): li.setArt({'thumb': tmdb['poster'], 'poster': tmdb['poster']})
            li.setInfo('video', {'plot': tmdb.get('plot', '')})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(_handle, get_url(action='play_hellspy', vid_id=r['id'], fhash=r['hash']), li, False)
    
    token = revalidate()
    if token:
        req = urllib.request.Request("https://webshare.cz/api/search/", data=urlencode({'what': query, 'wst': token, 'limit': '50', 'category': 'video'}).encode(), headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=10, context=ctx_unverified) as res:
            content = res.read().decode('utf-8')
            idents = re.findall(r'<ident>([^<]+)</ident>', content)
            names = re.findall(r'<name>([^<]+)</name>', content)
            for i in range(len(idents)):
                li = xbmcgui.ListItem(label=f"[COLOR orange][WS][/COLOR] {names[i]}")
                if tmdb:
                    if tmdb.get('poster'): li.setArt({'thumb': tmdb['poster'], 'poster': tmdb['poster']})
                    li.setInfo('video', {'plot': tmdb.get('plot', '')})
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(_handle, get_url(action='play_trezor', stream_url=f"https://webshare.cz/file/{idents[i]}/"), li, False)
    xbmcplugin.endOfDirectory(_handle)

def play_hellspy(params):
    vid_id, fhash = params.get('vid_id'), params.get('fhash')
    url = f"https://api.hellspy.to/gw/video/{vid_id}/{fhash}"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA})) as res:
            data = json.loads(res.read().decode('utf-8'))
            stream_url = data.get('download') or list(data.get('conversions', {}).values())[0]
            xbmcplugin.setResolvedUrl(_handle, True, xbmcgui.ListItem(path=stream_url))
    except: xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def play_trezor(params):
    stream_url = unquote(params.get('stream_url', ''))
    source = params.get('source', 'Webshare')
    if source == 'Hellshare':
        real_url = get_hellshare_stream(stream_url)
        if real_url:
            xbmcplugin.setResolvedUrl(_handle, True, xbmcgui.ListItem(path=real_url))
            return
    else:
        ident = re.search(r'([a-zA-Z0-9]{10})', stream_url)
        if ident:
            token = revalidate()
            link = getlink(ident.group(1), token)
            if link:
                li = xbmcgui.ListItem(path=link + '|' + urlencode({'User-Agent': UA, 'Cookie': 'wst=' + token}))
                xbmcplugin.setResolvedUrl(_handle, True, li)
                return
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def choose_source(params):
    name, cat = params.get('name'), params.get('category')
    try:
        with urllib.request.urlopen(urllib.request.Request(f"{TREZOR_WEB_URL}?cat={cat}", headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as res:
            all_streams = json.loads(res.read().decode('utf-8'))
            streams = [s for s in all_streams if s.get('name', '').strip() == name]
        
        for s in streams:
            source_name = s.get('source', 'Webshare')
            label_prefix = "[COLOR blue][HS][/COLOR]" if source_name == 'Hellshare' else "[COLOR orange][WS][/COLOR]"
            
            # Získání hodnoty velikosti
            val_size = s.get('size', '')
            # Pokud je velikost prázdná, zkusíme vzít epizodu
            val_ep = s.get('episode', '')
            
            # Sestavení labelu: [TAG] Název + Velikost/Epizoda
            label = f"{label_prefix} {s.get('name')} {val_ep} {val_size}".strip()
            
            li = xbmcgui.ListItem(label=label)
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(_handle, get_url(action='play_trezor', stream_url=s.get('url', ''), source=source_name), li, False)
    except Exception as e:
        xbmc.log(f"CHYBA choose_source: {str(e)}", level=xbmc.LOGERROR)
        
    xbmcplugin.endOfDirectory(_handle)

def list_movies_in_category(params):
    xbmcplugin.setContent(_handle, 'movies')
    cat = params.get('category', 'all')
    try:
        with urllib.request.urlopen(urllib.request.Request(f"{TREZOR_WEB_URL}?cat={cat}", headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as res:
            all_streams = json.loads(res.read().decode('utf-8'))
            grouped = {}
            for s in all_streams:
                if cat != 'all' and s.get('category') != cat: continue
                name = s.get('name', '').strip()
                if name not in grouped: grouped[name] = []
                grouped[name].append(s)
            
            for name, streams in grouped.items():
                tmdb = get_tmdb_info(name)
                # Název složky s decentním počtem verzí
                label = f"{name} [COLOR gray]({len(streams)}x)[/COLOR]" if len(streams) > 1 else name
                
                li = xbmcgui.ListItem(label=label)
                if tmdb:
                    if tmdb.get('poster'): li.setArt({'thumb': tmdb['poster'], 'poster': tmdb['poster']})
                    li.setInfo('video', {'plot': tmdb.get('plot', '')})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='choose_source', category=cat, name=name), li, True)
    except: pass
    xbmcplugin.endOfDirectory(_handle)

def list_nas_videos(params):
    xbmcplugin.setContent(_handle, 'movies')
    subpath = params.get('subpath', '')
    target_path = NAS_BASE_PATH + subpath
    try:
        dirs, files = xbmcvfs.listdir(target_path)
        for d in dirs:
            if d.lower() in ['repo', 'system', '.system', 'thumbnails']: continue
            xbmcplugin.addDirectoryItem(_handle, get_url(action='nas_video', subpath=subpath + d + "/"), xbmcgui.ListItem(label=d), True)
        for f in files:
            if f.lower().endswith(('.mkv', '.mp4', '.avi')):
                li = xbmcgui.ListItem(label=f)
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(_handle, target_path + f, li, False)
    except: pass
    xbmcplugin.endOfDirectory(_handle)

def list_tv_program():
    xbmcplugin.setContent(_handle, 'movies')
    xml_path = os.path.join(_addon.getAddonInfo('path'), 'program.xml')
    if not os.path.exists(xml_path): return
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    stanice = params.get('stanice')
    today = datetime.datetime.now().strftime("%Y%m%d")
    now = datetime.datetime.now().strftime("%H%M")
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
        if not stanice:
            for channel in root.findall('channel'):
                chan_id = channel.get('id')
                name_elem = channel.find('display-name')
                raw_name = name_elem.text if name_elem is not None else chan_id
                clean_name = re.sub(r'[^a-zA-Z0-9ěščřžýáíéúůĚŠČŘŽÝÁÍÉÚŮ\s]', '', raw_name.split('|')[0]).strip()
                xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_program', stanice=chan_id), xbmcgui.ListItem(label=clean_name), True)
        else:
            prog_list = [p for p in root.findall(f".//programme[@channel='{stanice}']") if p.get('start', '').startswith(today)]
            for i in range(len(prog_list)):
                prog = prog_list[i]
                title = prog.find('title').text
                tmdb = get_tmdb_info(title)
                start_str = prog.get('start')[8:12]
                next_start = prog_list[i+1].get('start')[8:12] if i + 1 < len(prog_list) else "2400"
                label = f"[{start_str[:2]}:{start_str[2:]}] {title}"
                if start_str <= now < next_start: label = f"[COLOR gold]{label} [NYNÍ VYSÍLÁNO][/COLOR]"
                li = xbmcgui.ListItem(label=label)
                if tmdb:
                    if tmdb.get('poster'): li.setArt({'thumb': tmdb['poster'], 'poster': tmdb['poster']})
                    li.setInfo('video', {'plot': tmdb.get('plot', '')})
                xbmcplugin.addDirectoryItem(_handle, get_url(action='search_both', query=title), li, True)
    except: pass
    xbmcplugin.endOfDirectory(_handle)

def main():
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    action = params.get('action')
    
    if not action:
        xbmcplugin.addDirectoryItem(_handle, get_url(action='trezor'), xbmcgui.ListItem(label='[COLOR gold] VIP TREZOR [/COLOR]'), True)
        xbmcplugin.addDirectoryItem(_handle, get_url(action='tv_program'), xbmcgui.ListItem(label='[COLOR gold] TV PROGRAM [/COLOR]'), True)
        xbmcplugin.addDirectoryItem(_handle, get_url(action='search_menu'), xbmcgui.ListItem(label='[COLOR blue] HLEDAT [/COLOR]'), True)
        xbmcplugin.addDirectoryItem(_handle, get_url(action='none'), xbmcgui.ListItem(label=get_webshare_vip_info(revalidate())), False)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'search_menu':
        xbmcplugin.addDirectoryItem(_handle, get_url(action='new_search'), xbmcgui.ListItem(label='[COLOR green]NOVÉ HLEDÁNÍ[/COLOR]'), True)
        xbmcplugin.addDirectoryItem(_handle, get_url(action='show_history'), xbmcgui.ListItem(label='HISTORIE HLEDÁNÍ'), True)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'new_search':
        q = get_user_query()
        if q: save_to_history(q); search_both({'query': q})
    elif action == 'show_history':
        if xbmcvfs.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                for line in f.read().splitlines():
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='search_both', query=line), xbmcgui.ListItem(label=line), True)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'search_both': search_both(params)
    elif action == 'trezor':
        for id, label in [('serialy', 'Seriály'), ('ceske', 'České filmy'), ('zahranicni', 'Zahraniční filmy')]:
            xbmcplugin.addDirectoryItem(_handle, get_url(action='list_category', category=id), xbmcgui.ListItem(label=label), True)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'list_category': list_movies_in_category(params)
    elif action == 'choose_source': choose_source(params)
    elif action == 'tv_program': list_tv_program()
    elif action == 'nas_video': list_nas_videos(params)
    elif action == 'play_hellspy': play_hellspy(params)
    elif action == 'play_trezor': play_trezor(params)

if __name__ == '__main__': main()