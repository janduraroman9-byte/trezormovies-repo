# -*- coding: utf-8 -*-
import urllib.request, urllib.error, urllib.parse
import re
import xbmc
import time

CSFD_BASE = 'https://www.csfd.cz'
CSFD_SEARCH = 'https://www.csfd.cz/hledat/?q='
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Referer': 'https://www.csfd.cz/'
}

_cache = {}

def get_data(query):
    if not query: return None
    if query in _cache: return _cache[query]
    
    # Přidáme krátkou pauzu pro ochranu před banem (0.5s)
    time.sleep(0.5)
    
    try:
        # 1. Hledání
        search_url = CSFD_SEARCH + urllib.parse.quote(query.encode('utf-8'))
        req = urllib.request.Request(search_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8', errors='replace')
        
        url_match = re.search(r'href="(/film/\d+[^"]*)"', html)
        if not url_match:
            _cache[query] = None
            return None
        
        # 2. Detail
        film_url = CSFD_BASE + url_match.group(1)
        req = urllib.request.Request(film_url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=10) as response:
            film_html = response.read().decode('utf-8', errors='replace')
        
        # 3. Extrakce
        rating_match = re.search(r'film-rating-average">(\d+%)', film_html)
        poster_match = re.search(r'property="og:image"\s+content="([^"]+)"', film_html)
        plot_match = re.search(r'property="og:description"\s+content="([^"]+)"', film_html)
        
        data = {
            'rating': rating_match.group(1) if rating_match else 'N/A',
            'poster': poster_match.group(1) if poster_match else '',
            'plot': plot_match.group(1).strip() if plot_match else 'Bez popisu.'
        }
        
        _cache[query] = data
        return data
        
    except Exception as e:
        xbmc.log("CSFD_SCRAPER CHYBA: " + str(e), xbmc.LOGERROR)
        # Vrátíme prázdná data, aby se doplněk nezhroutil
        return {'rating': 'N/A', 'poster': '', 'plot': 'Nelze načíst data.'}