# -*- coding: utf-8 -*-
import sys, os, re, hashlib, json, ssl, urllib.request, urllib.error
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from urllib.parse import urlparse, parse_qsl, urlencode, unquote

# Inicializace
_addon = xbmcaddon.Addon()
_url = sys.argv[0]
_handle = int(sys.argv[1])

# Konfigurace
syno_ip = str(_addon.getSetting('trezor_ip')).strip() or "192.168.0.109"
TREZOR_WEB_URL = f"http://{syno_ip}/trezor/api.php"
TREZOR_SECRET_KEY = str(_addon.getSetting('trezor_wst')).strip()
TMDB_KEY = '16cb6df244a5695120296c6864a11686'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
ctx_unverified = ssl._create_unverified_context()

# --- POMOCNÉ FUNKCE ---
def python_md5crypt(password, salt):
    if salt.startswith('$1$'): salt = salt.split('$')[2]
    elif '$' in salt: salt = salt.split('$')[0]
    salt = salt[:8]
    p, s = password.encode('utf-8'), salt.encode('utf-8')
    ctx = hashlib.md5(p + b"$1$" + s)
    ctx1 = hashlib.md5(p + s + p).digest()
    plen = len(p)
    for i in range(plen, 0, -16): ctx.update(ctx1[:16] if i > 16 else ctx1[:i])
    i = plen
    while i > 0:
        ctx.update(b"\x00" if i & 1 else p[:1])
        i >>= 1
    final = ctx.digest()
    for i in range(1000):
        ctx1 = hashlib.md5()
        ctx1.update(p if i & 1 else final[:16])
        if i % 3: ctx1.update(s)
        if i % 7: ctx1.update(p)
        ctx1.update(final[:16] if i & 1 else p)
        final = ctx1.digest()
    itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    res = b"$1$" + s + b"$"
    def l64(v, n):
        r = b""
        while n > 0:
            r += itoa64[v & 0x3f].encode('ascii')
            v >>= 6; n -= 1
        return r
    final = list(final)
    res += l64((final[0]<<16)|(final[6]<<8)|final[12], 4)
    res += l64((final[1]<<16)|(final[7]<<8)|final[13], 4)
    res += l64((final[2]<<16)|(final[8]<<8)|final[14], 4)
    res += l64((final[3]<<16)|(final[9]<<8)|final[15], 4)
    res += l64((final[4]<<16)|(final[10]<<8)|final[5], 4)
    res += l64(final[11], 2)
    return res.decode('ascii')

def get_url(**kwargs): return f"{_url}?{urlencode(kwargs)}"

def get_tmdb_info(title):
    # Ošetření názvu pro TMDB
    clean_title = re.sub(r'(\d{4})', '', title).strip()
    url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_KEY}&query={urllib.parse.quote(clean_title)}&language=cs-CZ"
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': UA}), timeout=5) as res:
            data = json.loads(res.read().decode('utf-8'))
            if data.get('results'):
                item = data['results'][0]
                return {
                    'title': item.get('title') or item.get('name'),
                    'plot': item.get('overview', ''),
                    'poster': f"https://image.tmdb.org/t/p/w500{item.get('poster_path')}" if item.get('poster_path') else None
                }
    except: pass
    return None

def revalidate():
    username, password = str(_addon.getSetting('wsuser')).strip(), str(_addon.getSetting('wspass')).strip()
    if not username or not password: return None
    try:
        url_salt = "https://webshare.cz/api/salt/"
        with urllib.request.urlopen(urllib.request.Request(url_salt, data=urlencode({'username_or_email': username}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as response:
            salt = re.search(r'<salt>([^<]+)</salt>', response.read().decode()).group(1)
        crypt_str = python_md5crypt(password, salt)
        final_password_hash = hashlib.sha1(crypt_str.encode()).hexdigest().lower()
        final_digest = hashlib.md5(f"{username}:Webshare:{password}".encode()).hexdigest().upper()
        url_login = "https://webshare.cz/api/login/"
        with urllib.request.urlopen(urllib.request.Request(url_login, data=urlencode({'username_or_email': username, 'password': final_password_hash, 'digest': final_digest}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as response:
            res = response.read().decode()
            if 'OK' in res: return re.search(r'<token>([^<]+)</token>', res).group(1)
    except: pass
    return None

def getlink(ident, token):
    try:
        with urllib.request.urlopen(urllib.request.Request("https://webshare.cz/api/file_link/", data=urlencode({'ident': ident, 'wst': token}).encode(), headers={'User-Agent': UA}), timeout=10, context=ctx_unverified) as res:
            return re.search(r'<link>([^<]+)</link>', res.read().decode()).group(1)
    except: return None

# --- LOGIKA KODI ---
def list_movies_in_category(params):
    xbmcplugin.setContent(_handle, 'movies')
    cat = params.get('category', 'all')
    serial = params.get('serial', '')
    api_url = f"{TREZOR_WEB_URL}?wst={TREZOR_SECRET_KEY}&cat={cat}"
    if serial: api_url += f"&serial={serial}"
        
    try:
        with urllib.request.urlopen(api_url, timeout=10) as res:
            streamy = json.loads(res.read().decode('utf-8'))
            for s in streamy:
                tmdb = get_tmdb_info(s['name'])
                label = tmdb['title'] if tmdb and tmdb['title'] else s['name']
                
                li = xbmcgui.ListItem(label=label)
                if tmdb and tmdb['poster']:
                    li.setArt({'thumb': tmdb['poster'], 'poster': tmdb['poster']})
                if tmdb and tmdb['plot']:
                    li.setInfo('video', {'plot': tmdb['plot']})

                if s.get('is_serial'):
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='list_category', category=cat, serial=s['name']), li, True)
                else:
                    li.setProperty('IsPlayable', 'true')
                    xbmcplugin.addDirectoryItem(_handle, get_url(action='play_trezor', stream_url=s['url']), li, False)
    except: pass
    xbmcplugin.endOfDirectory(_handle)

def play_trezor(params):
    url = unquote(params.get('stream_url', ''))
    ident = re.search(r'([a-zA-Z0-9]{10})', url)
    if ident:
        token = revalidate()
        link = getlink(ident.group(1), token)
        if link:
            li = xbmcgui.ListItem(path=link + '|' + urlencode({'User-Agent': UA, 'Cookie': 'wst=' + token}))
            xbmcplugin.setResolvedUrl(_handle, True, li)
            return
    xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())

def main():
    params = dict(parse_qsl(urlparse(sys.argv[2]).query))
    action = params.get('action')
    if not action:
        li = xbmcgui.ListItem(label='[COLOR gold]*** VIP TREZOR ***[/COLOR]')
        xbmcplugin.addDirectoryItem(_handle, get_url(action='trezor'), li, True)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'trezor': 
        cats = [('serialy', 'Seriály'), ('ceske', 'České filmy'), ('zahranicni', 'Zahraniční filmy')]
        for id, label in cats:
            li = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(_handle, get_url(action='list_category', category=id), li, True)
        xbmcplugin.endOfDirectory(_handle)
    elif action == 'list_category': list_movies_in_category(params)
    elif action == 'play_trezor': play_trezor(params)

if __name__ == '__main__': main()